EduConnectPro - Run server and open client/index.html with Live Server
